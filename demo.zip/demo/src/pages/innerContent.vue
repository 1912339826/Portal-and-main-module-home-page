<template>
 <iframe src="https://blog.csdn.net/weixin_41767649/article/details/79397163" height="2000px;" width="1000px;"></iframe>
</template>
<script>
  export default {
    name:"innerContent"
  }
</script>
