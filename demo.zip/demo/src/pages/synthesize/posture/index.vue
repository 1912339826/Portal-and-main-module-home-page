// 态势
<template>
    <div class="posture">
        态势
        这里是一个二级页面
    </div>
</template>
<script>
export default {
    name:"posture"
}
</script>