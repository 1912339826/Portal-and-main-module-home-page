<template>
    <div id="threeLV">
        这是一个三级页面的实例
    </div>
</template>

<script>
export default {
    name:"threeLV"
}
</script>